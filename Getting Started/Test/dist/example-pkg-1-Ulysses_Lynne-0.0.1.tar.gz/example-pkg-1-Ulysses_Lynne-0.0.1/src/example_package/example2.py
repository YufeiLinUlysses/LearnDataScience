class test1():
    h = "helloWorld"

    def testhaha(self):
        print(self.h)
